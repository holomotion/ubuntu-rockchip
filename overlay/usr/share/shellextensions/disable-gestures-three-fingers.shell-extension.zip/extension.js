/**
 * Disable Gestures 2021
 *
 * A GNOME extension that disables three-finger or more gestures. 
 * Useful for kiosks and touchscreen apps.
 */
export default class Extension {
  focusWindowId = null
  inFullscreenChangedId = null

  enable() {
    global.stage.get_actions().forEach(action => {
      // 只禁用需要3个或更多触点的手势
      if (action.get_n_touch_points && action.get_n_touch_points() >= 3) {
        action.enabled = false
      }
    })
    
    const disableMultiTouchGesture = () => {
      global.stage.get_actions().forEach(action => {
        if (action === this) return
        if (action.get_n_touch_points && action.get_n_touch_points() >= 3) {
          action.enabled = false
        }
      })
    }
    
    if (this.focusWindowId === null) {
      this.focusWindowId = global.display.connect('notify::focus-window', disableMultiTouchGesture)
    }
    if (this.inFullscreenChangedId === null) {
      this.inFullscreenChangedId = global.display.connect('in-fullscreen-changed', disableMultiTouchGesture)
    }
  }

  disable() {
    if (this.inFullscreenChangedId !== null) {
      global.display.disconnect(this.inFullscreenChangedId)
      this.inFullscreenChangedId = null
    }
    if (this.focusWindowId !== null) {
      global.display.disconnect(this.focusWindowId)
      this.focusWindowId = null
    }
    global.stage.get_actions().forEach(action => {
      if (action.get_n_touch_points && action.get_n_touch_points() >= 3) {
        action.enabled = true
      }
    })
  }
}
